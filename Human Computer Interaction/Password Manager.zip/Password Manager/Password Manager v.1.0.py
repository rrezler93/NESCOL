# Radoslaw Rezler (30082939) Password app prototype.

# FINISHED:
# whole interface (4 windows together)
# date and time function
# help function
# colour function (all windows)
# show passwords function (written in passwords.txt file)
# generate 4 two digits number password function
# save password function

# ADDITIONAL INFORMATION:
# Some elements like keyboard or touch operations, or .apk/.exe versions are outside of project scope.
# Every function works fine, however using only guizero makes complicate to create an app with certain layout.
# User guide window is empty, as it is only prototype version. In addition, various errors are displayed in the console,
# the correction of which spoiled the layout of the application.
# However, they do not affect the correct operation of the running program.
# Last known problem: if passwords list will be too long, they may not be displayed correctly.
# "TextBox" allows to implement scrollbar, but also allows to edit all displayed passwords
# (no read-only parameters available). Then "Text" do not allow for scrollbar.
# If the "Box" would have "width" and "height" parameters set to "fill" (allows to resize the window if needed),
# whole interface won't be displayed correctly.

# Changes (v.1.0)
# Layout uses one single window (smoother experience, no "jumping" windows)
# Variables have better names now (code clearer to read and to operate on)
# Save password function works (all main components of the program works now)


# import all from guizero:
from guizero import *
# import time:
import time
# import random:
from random import randrange


# FUNCTIONS:


# Open first tab:
def open_first():
    # Change button colors:
    if first.bg == "#A1B4C3":
        button_saved_passwords.bg = "#748798"
        button_saved_passwords.text_color = "#ffffff"
        button_new_passwords.bg = "#E2E2E2"
        button_new_passwords.text_color = "#000000"
    else:
        button_new_passwords.bg = "#ffffff"
        button_new_passwords.text_color = "#000000"
        button_saved_passwords.bg = "#808080"
        button_saved_passwords.text_color = "#000000"

    # Hide second tab:
    box_separate15.hide()
    box_textboxes.hide()
    textbox5.hide()
    textbox5content.hide()
    box_separate16.hide()
    # Show first tab:
    box_separate3.show()
    box_for_numbers.show()
    textbox1.show()
    box_separate4.show()
    textbox2.show()
    box_separate5.show()
    textbox3.show()
    box_separate6.show()
    textbox4.show()
    box_separate7.show()
    box_buttons2.show()
    button_save.show()
    box_separate8.show()
    button_generate.show()
    box_separate9.show()


# Open second tab:
def open_second():
    # Change button colors:
    if first.bg == "#A1B4C3":
        button_new_passwords.bg = "#748798"
        button_new_passwords.text_color = "#ffffff"
        button_saved_passwords.bg = "#E2E2E2"
        button_saved_passwords.text_color = "#000000"
    else:
        button_new_passwords.bg = "#808080"
        button_new_passwords.text_color = "#000000"
        button_saved_passwords.bg = "#ffffff"
        button_saved_passwords.text_color = "#000000"

    # Hide first tab:
    box_separate3.hide()
    box_for_numbers.hide()
    textbox1.hide()
    box_separate4.hide()
    textbox2.hide()
    box_separate5.hide()
    textbox3.hide()
    box_separate6.hide()
    textbox4.hide()
    box_separate7.hide()
    box_buttons2.hide()
    button_save.hide()
    box_separate8.hide()
    button_generate.hide()
    box_separate9.hide()

    # Show second tab:
    box_separate15.show()
    box_textboxes.show()
    textbox5.show()
    textbox5content.show()
    box_separate16.show()

    # Pass content of .txt file to the Box:
    file = open("passwords.txt", "r")
    content = file.read()
    textbox5content.value = content
    file.close()


# Show manual:
def open_help():
    manual.show()


# Change colors:
def update_colors():
    if button_new_passwords.bg == "#E2E2E2":
        first.bg = "black"
        button_new_passwords.bg = "#ffffff"
        button_new_passwords.text_color = "#000000"
        button_saved_passwords.bg = "#808080"
        button_saved_passwords.text_color = "#000000"
        box_top.bg = "white"
        box_bottom.bg = "white"
        box_bottom1.bg = "white"
        textbox1.bg = "white"
        textbox2.bg = "white"
        textbox3.bg = "white"
        textbox4.bg = "white"
        textbox5.bg = "white"
        button_save.bg = "grey"
        button_save.text_color = "black"
        button_generate.bg = "grey"
        button_generate.text_color = "black"
        button_color.bg = "grey"
        button_color1.bg = "grey"
        button_manual.bg = "grey"
        button_manual1.bg = "grey"
        button_color.text_color = "black"
        button_color1.text_color = "black"
        button_manual.text_color = "black"
        button_manual1.text_color = "black"
        manual.bg = "white"
        description.bg = "black"
        box_top2.bg = "#ffffff"
        textbox6.bg = "white"
        button_write.text_color = "black"
        button_write.bg = "grey"
    elif button_new_passwords.bg == "#748798":
        first.bg = "black"
        button_new_passwords.bg = "#808080"
        button_new_passwords.text_color = "#000000"
        button_saved_passwords.bg = "#ffffff"
        button_saved_passwords.text_color = "#000000"
        box_top.bg = "white"
        box_bottom.bg = "white"
        box_bottom1.bg = "white"
        textbox1.bg = "white"
        textbox2.bg = "white"
        textbox3.bg = "white"
        textbox4.bg = "white"
        textbox5.bg = "white"
        button_save.bg = "grey"
        button_save.text_color = "black"
        button_generate.bg = "grey"
        button_generate.text_color = "black"
        button_color.bg = "grey"
        button_color1.bg = "grey"
        button_manual.bg = "grey"
        button_manual1.bg = "grey"
        button_color.text_color = "black"
        button_color1.text_color = "black"
        button_manual.text_color = "black"
        button_manual1.text_color = "black"
        manual.bg = "white"
        description.bg = "black"
        box_top2.bg = "#ffffff"
        textbox6.bg = "white"
        button_write.text_color = "black"
        button_write.bg = "grey"
    elif button_new_passwords.bg == "#ffffff":
        first.bg = "#A1B4C3"
        button_saved_passwords.bg = "#748798"
        button_saved_passwords.text_color = "#ffffff"
        button_new_passwords.bg = "#E2E2E2"
        button_new_passwords.text_color = "#000000"
        box_top.bg = "#E2E2E2"
        box_bottom.bg = "#E2E2E2"
        box_bottom1.bg = "#E2E2E2"
        textbox1.bg = "white"
        textbox2.bg = "white"
        textbox3.bg = "white"
        textbox4.bg = "white"
        textbox5.bg = "white"
        button_save.bg = "#748798"
        button_save.text_color = "white"
        button_generate.bg = "#748798"
        button_generate.text_color = "white"
        button_manual.bg = "#748798"
        button_manual.text_color = "white"
        button_manual1.bg = "#748798"
        button_manual1.text_color = "white"
        button_color.bg = "#748798"
        button_color.text_color = "white"
        button_color1.bg = "#748798"
        button_color1.text_color = "white"
        manual.bg = "#A1B4C3"
        description.bg = "#A1B4C3"
        box_top2.bg = "#E2E2E2"
        textbox6.bg = "white"
        button_write.text_color = "white"
        button_write.bg = "#748798"
    else:
        first.bg = "#A1B4C3"
        button_new_passwords.bg = "#748798"
        button_new_passwords.text_color = "#ffffff"
        button_saved_passwords.bg = "#E2E2E2"
        button_saved_passwords.text_color = "#000000"
        box_top.bg = "#E2E2E2"
        box_bottom.bg = "#E2E2E2"
        box_bottom1.bg = "#E2E2E2"
        textbox1.bg = "white"
        textbox2.bg = "white"
        textbox3.bg = "white"
        textbox4.bg = "white"
        textbox5.bg = "white"
        button_save.bg = "#748798"
        button_save.text_color = "white"
        button_generate.bg = "#748798"
        button_generate.text_color = "white"
        button_manual.bg = "#748798"
        button_manual.text_color = "white"
        button_manual1.bg = "#748798"
        button_manual1.text_color = "white"
        button_color.bg = "#748798"
        button_color.text_color = "white"
        button_color1.bg = "#748798"
        button_color1.text_color = "white"
        manual.bg = "#A1B4C3"
        description.bg = "#A1B4C3"
        box_top2.bg = "#E2E2E2"
        textbox6.bg = "white"
        button_write.text_color = "white"
        button_write.bg = "#748798"


# Add password to passwords.txt:
def add():
    description.show(wait=True)


def save():
    pwd = f"{textbox1.value} {textbox2.value} {textbox3.value} {textbox4.value}"
    name = textbox6.value
    with open('passwords.txt', 'a') as new:
        new.write(f"{pwd} - {time.strftime('%X %x')}\n{name}\n")
    textbox1.clear()
    textbox2.clear()
    textbox3.clear()
    textbox4.clear()
    textbox6.value = "Please write a description."
    description.hide()


def generate():
    textbox1.value = randrange(10, 99)
    textbox2.value = randrange(10, 99)
    textbox3.value = randrange(10, 99)
    textbox4.value = randrange(10, 99)


# FIRST PAGE:


# Basic details about the app:
first = App(title="Password Manager", width=300, height=377, layout="grid")
first.bg = "#A1B4C3"

# Title:
box_top = Box(first, width=300, height=45, border=True, grid=[0, 0])
box_top.bg = "#E2E2E2"
title = Text(box_top, text="Your passwords", size=16, height="fill")

# Separate:
box_separate1 = Box(first, height=50, grid=[0, 1])

# Buttons:
box_buttons1 = Box(first, layout="grid", grid=[0, 2])

button_new_passwords = PushButton(box_buttons1, text="New passwords", width=15, grid=[0, 0], command=open_first)
button_new_passwords.bg = "#E2E2E2"

box_separate2 = Box(box_buttons1, width=10, grid=[1, 0])

button_saved_passwords = PushButton(box_buttons1, text="Saved passwords", width=15, grid=[2, 0], command=open_second)
button_saved_passwords.text_color = "white"
button_saved_passwords.bg = "#748798"

# Separate:
box_separate3 = Box(first, height=37, grid=[0, 3])

# Text Boxes for numbers:
box_for_numbers = Box(first, layout="grid", grid=[0, 4])

textbox1 = TextBox(box_for_numbers, width=5, grid=[0, 0])
textbox1.bg = "white"
textbox1.text_size = 12
box_separate4 = Box(box_for_numbers, width=10, grid=[1, 0])
textbox2 = TextBox(box_for_numbers, width=5, grid=[2, 0])
textbox2.text_size = 12
textbox2.bg = "white"
box_separate5 = Box(box_for_numbers, width=10, grid=[3, 0])
textbox3 = TextBox(box_for_numbers, width=5, grid=[4, 0])
textbox3.text_size = 12
textbox3.bg = "white"
box_separate6 = Box(box_for_numbers, width=10, grid=[5, 0])
textbox4 = TextBox(box_for_numbers, width=5, grid=[6, 0])
textbox4.text_size = 12
textbox4.bg = "white"

# Separate:
box_separate7 = Box(first, height=37, grid=[0, 5])

# Save and generate buttons:
box_buttons2 = Box(first, layout="grid", grid=[0, 6])

button_save = PushButton(box_buttons2, text="Save", grid=[0, 0], command=add)
button_save.bg = "#748798"
button_save.text_color = "white"
button_save.width = 7

box_separate8 = Box(box_buttons2, width=10, grid=[1, 0])

button_generate = PushButton(box_buttons2, text="Generate", grid=[2, 0], command=generate)
button_generate.bg = "#748798"
button_generate.text_color = "white"
button_generate.width = 7

# Separate:
box_separate9 = Box(first, height=50, grid=[0, 7])

# Bottom
box_bottom = Box(first, layout="grid", width=300, height=45, border=True, grid=[0, 8])
box_bottom.bg = "#E2E2E2"

box_separate10 = Box(box_bottom, width=5, grid=[0, 0])

# Date and time:
date_and_time1 = Text(box_bottom, text=time.strftime('%X %x'), size=10, grid=[1, 0])


def counter():
    date_and_time1.value = time.strftime('%X %x')


date_and_time1.repeat(1000, counter)

box_separate11 = Box(box_bottom, width=95, grid=[2, 0])

button_manual1 = PushButton(box_bottom, text="Help", grid=[3, 0], command=open_help)
button_manual1.text_color = "white"
button_manual1.width = 2
button_manual1.bg = "#748798"

box_separate12 = Box(box_bottom, width=5, grid=[4, 0])

button_color1 = PushButton(box_bottom, text="Color", grid=[5, 0], command=update_colors)
button_color1.text_color = "white"
button_color1.width = 2
button_color1.bg = "#748798"

# SECOND PAGE:


# Separate:
box_separate15 = Box(first, height=12, grid=[0, 3])
box_separate15.hide()

# Text and Boxes for numbers:
box_textboxes = Box(first, grid=[0, 4])
box_textboxes.hide()

textbox5 = Box(box_textboxes, width=275, height=164)
textbox5.hide()
textbox5.bg = "white"
textbox5content = Text(textbox5, text="No saved passwords.", size=10, width="fill", height="fill")
textbox5content.hide()

# Separate:
box_separate16 = Box(first, height=17, grid=[0, 5])
box_separate16.hide()

# Bottom
box_bottom1 = Box(first, layout="grid", width=300, height=45, border=True, grid=[0, 8])
box_bottom1.bg = "#E2E2E2"

box_separate17 = Box(box_bottom1, width=5, grid=[0, 0])

# Date and time:
date_and_time2 = Text(box_bottom1, text=time.strftime('%X %x'), size=10, grid=[1, 0])


def counter():
    date_and_time2.value = time.strftime('%X %x')


date_and_time2.repeat(1000, counter)

box_separate18 = Box(box_bottom1, width=95, grid=[2, 0])

button_manual = PushButton(box_bottom1, text="Help", grid=[3, 0], command=open_help)
button_manual.text_color = "white"
button_manual.width = 2
button_manual.bg = "#748798"

box_separate19 = Box(box_bottom1, width=5, grid=[4, 0])

button_color = PushButton(box_bottom1, text="Color", grid=[5, 0], command=update_colors)
button_color.text_color = "white"
button_color.width = 2
button_color.bg = "#748798"

# MANUAL:


manual = Window(first, title="Help", width=377, height=377)
manual.bg = "#A1B4C3"
manual.hide()

instructions = Text(manual, text="User guide with explanation of all functions.", size=10, height="fill", width="fill")

# PASSWORD DESCRIPTION:


description = Window(first, title="Description", width=300, height=200, layout="grid")
description.bg = "#A1B4C3"
description.hide()

box_top2 = Box(description, width=300, height=45, border=True, grid=[0, 0])
box_top2.bg = "#E2E2E2"
title2 = Text(box_top2, text="Password description", size=16, height="fill")

box_separate20 = Box(description, height=10, grid=[0, 1])

textbox6 = TextBox(description, multiline=True, width=32, height=5, grid=[0, 2], text="Please write a description.")
textbox6.bg = "white"

box_separate21 = Box(description, height=10, grid=[0, 3])

button_write = PushButton(description, text="Save", grid=[0, 4], command=save)
button_write.text_color = "white"
button_write.width = 10
button_write.bg = "#748798"

# RUN:


first.display()
