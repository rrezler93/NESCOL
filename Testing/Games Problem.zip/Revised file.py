# Radoslaw Rezler
# HND Software Development
# Lecturer: Christie Nyssen
# Date: 29/05/2023

import random


# function to guess letters in selected word

def letterguess(wordlist, hintlist, score):
    wordchoice = getword(wordlist, hintlist)
    count = 0
    print("You have 6 letter guesses")

    while count < 6:
        letterguess = input("What letter do you want to try? ")
        if letterguess in wordchoice:
            print("Letter is in the word.")
        else:
            print("Letter is not in the word.")
        count += 1

    score = wordguess(wordchoice, score)
    return score


# function to jumble letters and allow guess
def wordjumble(wordlist, hintlist, score):
    count = 0
    wordchoice = getword(wordlist, hintlist)
    high = len(wordchoice)
    low = -len(wordchoice)
    while count < 10:
        position = random.randrange(low, high)
        print(wordchoice[position])
        count += 1
    score = wordguess(wordchoice, score)
    return score

# function to check score
def checkscore(score, player):
    print(player + ", you have scored, " + str(score) + " points.")


# function to display manual
def menu():
    print("""      Menu
1.  Guess the word
2.  Word jumble              
3.  Check your score
4.  Exit""")  # choices in menu
    answer = input("Make a selection: ")  # user input
    return answer


# function to check top scorer
def highscore():
    try:
        inp = open("topscore.txt", "r")
        topscore = int(inp.read())
        print("Topscore is: " + str(topscore))
        inp.close()
        return topscore
    except:
        print("Error - no file.")
        topscore = 0
        return topscore


# function to allow word guesses
def wordguess(wordchoice, score):
    count = 0
    while count < 3:
        userguess = input("What word do you want to try? ")
        count += 1
        if userguess == wordchoice:
            print("Correct, you have guessed correctly.")
            score += 1
            return score
        else:
            print("No luck, try again.")
    return score


# function to randomly select word from list
def getword(wordlist, hintlist):
    wordnums = len(wordlist)
    randompick = random.randrange(0, wordnums)
    wordchoice = wordlist[randompick]
    print("The length of the word is " + str(len(wordchoice)))
    print(hintlist[randompick])
    return wordchoice


# function to update file with topscorer
def replacescore(thisplayer, topscore):
    if thisplayer > topscore:
        print("You are now top scorer!")
        highscore = open("topscore.txt", "w")
        highscore.write(str(thisplayer))
        highscore.close()
    else:
        print("You have not topped the score this time.")


# main program

wordlist = ["cat", "dog", "monkey", "garden", "computer"]
hintlist = ["furry", "friendly", "with tail", "peaceful", "work"]

score = 0
thisplayer = 0
answer = 0
topscore = highscore()
player = input("What is your name? ")

while answer != "4":  # controls menu
    answer = menu()
    if "1" in answer:
        score = letterguess(wordlist, hintlist, score)
    if "2" in answer:
        score = wordjumble(wordlist, hintlist, score)
    if "3" in answer:
        checkscore(score, player)
    if "4" in answer:
        thisplayer = score
        replacescore(thisplayer, topscore)
        break
    if answer not in ["1", "2", "3", "4"]:
        print("Wrong value, retry.")
