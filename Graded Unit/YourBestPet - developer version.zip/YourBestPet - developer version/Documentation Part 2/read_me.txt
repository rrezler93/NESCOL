Welcome to the guide for the "YoutBestPet" application.

The application was created to raise awareness about domestic animals 
and facilitate the selection of one of them. 
The project was commissioned by NESCOL as a Graded Unit Project.

Author: 	Radoslaw Rezler
		30082939

Please open in the following order: 

YourBestPet - developer version > 
Documentation Part 2 > 
Radoslaw Rezler - Graded Unit 2023 - Additional documentation.docx

T​his document contains all the information regarding the 
internal structure of the folders as well as technical documentation, 
including the testing phase and user manual.