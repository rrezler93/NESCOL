#!/bin/bash

# Function to display the menu
display_menu() {
    echo "=========================="
    echo "         MENU             "
    echo "=========================="
    echo "1. Show the manual path"
    echo "2. Add an item to the manual path"
    echo "3. Set the manual path to '/man'"
    echo "4. Enter a filename"
    echo "5. Edit the file"
    echo "6. Display the head of the file"
    echo "7. Display the tail of the file"
    echo "8. Display a listing of processes in long listing"
    echo "9. Count processes for a user"
    echo "0. Exit"
    echo "=========================="
}

# Function to show the manual path
show_manual_path() {
    echo "The current manual path is: $MANPATH"
}

# Function to add an item to the manual path
add_to_manual_path() {
    read -rp "Enter the item to add: " item # -rp is used to display a prompt and read the input from the user
    export MANPATH=$MANPATH:$item # add the item to the manual path
    echo "Item '$item' added to the manual path." # $item is the item to add to the manual path
}

# Function to set the manual path to "/man"
set_manual_path() {
    export MANPATH="/man" # sets $MANPATH to /man
    echo "Manual path set to '/man'."
}

# Function to enter a filename
enter_filename() {
    read -rp "Enter the filename: " -r filename # -r is used to read the input as a raw string
}

# Function to edit the file
edit_file() {
    if [ -z "$filename" ]; then # -z is used to check if the variable is empty
        echo "No filename entered."  # if the filename is empty, display an error message
    else
        vim "$filename" # if the filename is not empty, open the file in vim
    fi
}

# Function to display the head of the file
display_file_head() {
    if [ -z "$filename" ]; then # -z is used to check if the variable is empty
        echo "No filename entered." # if the filename is empty, display an error message
    else
        read -rp "Enter the number of lines to display: " -r lines
        head -n "$lines" "$filename" # if the filename is not empty, display the head of the file
    fi
}

# Function to display the tail of the file
display_file_tail() {
    if [ -z "$filename" ]; then # -z is used to check if the variable is empty
        echo "No filename entered. " # if the filename is empty, display an error message
    else
        read -rp "Enter the number of lines to display: " -r lines
        tail -n "$lines" "$filename" # if the filename is not empty, display the tail of the file
    fi
}

# Function to display a listing of processes in long listing
display_processes() {
    ps -ef
}

# Function to count processes for a user
count_processes_for_user() {
    read -rp "Enter the username: " username # read the username from the user
    process_count=$(ps -u "$username" | wc -l)  # wc -l is used to count the number of lines
    echo "The number of processes for user '$username' is: $process_count" # display the number of processes for the user
}


# Main script
clear # clear the screen
display_menu # display the menu

while true; do
    read -rp "Enter your choice (0-9): " choice # read the choice from the user

    case $choice in # case statement to check the choice
        1) show_manual_path ;;
        2) add_to_manual_path ;;
        3) set_manual_path ;;
        4) enter_filename ;;
        5) edit_file ;;
        6) display_file_head ;;
        7) display_file_tail ;;
        8) display_processes ;;
        9) count_processes_for_user ;;
        0) echo "Exiting..."; exit ;;
        *) echo "Invalid choice. Please try again." ;;
    esac

    echo
    display_menu  # display the menu
done
